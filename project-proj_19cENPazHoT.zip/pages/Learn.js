function Learn() {
    try {
        const [courses, setCourses] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [selectedCategory, setSelectedCategory] = React.useState('all');

        React.useEffect(() => {
            loadCourses();
        }, []);

        const loadCourses = async () => {
            try {
                const data = await api.getCourses();
                setCourses(data);
            } catch (error) {
                console.error('Failed to load courses:', error);
            } finally {
                setLoading(false);
            }
        };

        const categories = [
            { id: 'all', name: 'All Courses' },
            { id: 'marketing', name: 'Digital Marketing' },
            { id: 'content', name: 'Content Creation' },
            { id: 'branding', name: 'Personal Branding' }
        ];

        const filteredCourses = selectedCategory === 'all' 
            ? courses 
            : courses.filter(course => course.category === selectedCategory);

        return (
            <div data-name="learn-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold mb-4">Learn & Grow</h1>
                    <p className="text-xl text-gray-600">Master the skills you need to succeed as an influencer</p>
                </div>

                <div className="flex flex-wrap gap-4 mb-8">
                    {categories.map(category => (
                        <Button
                            key={category.id}
                            variant={selectedCategory === category.id ? 'primary' : 'ghost'}
                            onClick={() => setSelectedCategory(category.id)}
                        >
                            {category.name}
                        </Button>
                    ))}
                </div>

                {loading ? (
                    <div className="text-center py-12">
                        <i className="fas fa-spinner fa-spin text-3xl text-indigo-600"></i>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredCourses.map(course => (
                            <Card
                                key={course.id}
                                className="flex flex-col"
                            >
                                <img
                                    src={course.thumbnail}
                                    alt={course.title}
                                    className="w-full h-48 object-cover rounded-lg mb-4"
                                />
                                <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
                                <p className="text-gray-600 mb-4 flex-grow">{course.description}</p>
                                <div className="flex items-center justify-between mt-4">
                                    <div className="flex items-center">
                                        <img
                                            src={course.instructor.avatar}
                                            alt={course.instructor.name}
                                            className="w-8 h-8 rounded-full mr-2"
                                        />
                                        <span className="text-sm text-gray-600">{course.instructor.name}</span>
                                    </div>
                                    <Button variant="secondary" size="sm">
                                        Start Learning
                                    </Button>
                                </div>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
        );
    } catch (error) {
        console.error('Learn page error:', error);
        reportError(error);
        return null;
    }
}
