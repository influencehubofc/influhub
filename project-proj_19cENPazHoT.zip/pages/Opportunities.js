function Opportunities() {
    try {
        const [opportunities, setOpportunities] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [filters, setFilters] = React.useState({
            category: 'all',
            platform: 'all',
            compensation: 'all'
        });

        React.useEffect(() => {
            loadOpportunities();
        }, [filters]);

        const loadOpportunities = async () => {
            try {
                const data = await api.getOpportunities(filters);
                setOpportunities(data);
            } catch (error) {
                console.error('Failed to load opportunities:', error);
            } finally {
                setLoading(false);
            }
        };

        return (
            <div data-name="opportunities-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold mb-4">Brand Opportunities</h1>
                    <p className="text-xl text-gray-600">Find and collaborate with brands that match your values</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    <div className="lg:col-span-1">
                        <Card className="sticky top-4">
                            <h3 className="text-lg font-semibold mb-4">Filters</h3>
                            
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Category
                                    </label>
                                    <select
                                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        value={filters.category}
                                        onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
                                    >
                                        <option value="all">All Categories</option>
                                        <option value="fashion">Fashion</option>
                                        <option value="tech">Technology</option>
                                        <option value="beauty">Beauty</option>
                                        <option value="lifestyle">Lifestyle</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Platform
                                    </label>
                                    <select
                                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        value={filters.platform}
                                        onChange={(e) => setFilters(prev => ({ ...prev, platform: e.target.value }))}
                                    >
                                        <option value="all">All Platforms</option>
                                        <option value="instagram">Instagram</option>
                                        <option value="tiktok">TikTok</option>
                                        <option value="youtube">YouTube</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Compensation
                                    </label>
                                    <select
                                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        value={filters.compensation}
                                        onChange={(e) => setFilters(prev => ({ ...prev, compensation: e.target.value }))}
                                    >
                                        <option value="all">All Types</option>
                                        <option value="paid">Paid</option>
                                        <option value="product">Product Exchange</option>
                                        <option value="commission">Commission</option>
                                    </select>
                                </div>
                            </div>
                        </Card>
                    </div>

                    <div className="lg:col-span-3">
                        {loading ? (
                            <div className="text-center py-12">
                                <i className="fas fa-spinner fa-spin text-3xl text-indigo-600"></i>
                            </div>
                        ) : (
                            <div className="space-y-6">
                                {opportunities.map(opportunity => (
                                    <Card key={opportunity.id} className="flex flex-col md:flex-row gap-6">
                                        <img
                                            src={opportunity.brand.logo}
                                            alt={opportunity.brand.name}
                                            className="w-full md:w-48 h-48 object-cover rounded-lg"
                                        />
                                        <div className="flex-grow">
                                            <div className="flex items-center justify-between mb-2">
                                                <h3 className="text-xl font-semibold">{opportunity.title}</h3>
                                                <span className="text-sm text-indigo-600 font-medium">
                                                    {opportunity.compensation.type}
                                                </span>
                                            </div>
                                            <p className="text-gray-600 mb-4">{opportunity.description}</p>
                                            <div className="flex flex-wrap gap-2 mb-4">
                                                {opportunity.requirements.map((req, index) => (
                                                    <span
                                                        key={index}
                                                        className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600"
                                                    >
                                                        {req}
                                                    </span>
                                                ))}
                                            </div>
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center">
                                                    <span className="text-sm text-gray-600 mr-4">
                                                        <i className="fas fa-calendar-alt mr-2"></i>
                                                        Deadline: {new Date(opportunity.deadline).toLocaleDateString()}
                                                    </span>
                                                    <span className="text-sm text-gray-600">
                                                        <i className="fas fa-users mr-2"></i>
                                                        {opportunity.applicants} applicants
                                                    </span>
                                                </div>
                                                <Button variant="primary">Apply Now</Button>
                                            </div>
                                        </div>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Opportunities page error:', error);
        reportError(error);
        return null;
    }
}
