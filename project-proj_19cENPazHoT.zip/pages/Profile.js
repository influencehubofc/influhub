function Profile() {
    try {
        const { user, updateUser } = useAuth();
        const [isEditing, setIsEditing] = React.useState(false);
        const [loading, setLoading] = React.useState(false);
        const [formData, setFormData] = React.useState({
            name: '',
            bio: '',
            location: '',
            website: '',
            instagram: '',
            youtube: '',
            tiktok: ''
        });

        React.useEffect(() => {
            if (user) {
                setFormData({
                    name: user.name || '',
                    bio: user.bio || '',
                    location: user.location || '',
                    website: user.website || '',
                    instagram: user.instagram || '',
                    youtube: user.youtube || '',
                    tiktok: user.tiktok || ''
                });
            }
        }, [user]);

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            try {
                const updatedUser = await api.updateProfile(formData);
                updateUser(updatedUser);
                setIsEditing(false);
            } catch (error) {
                console.error('Failed to update profile:', error);
            } finally {
                setLoading(false);
            }
        };

        if (!user) {
            return (
                <div className="text-center py-12">
                    <p>Please login to view your profile.</p>
                </div>
            );
        }

        return (
            <div data-name="profile-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="max-w-3xl mx-auto">
                    <div className="text-center mb-8">
                        <div className="relative inline-block">
                            <img
                                src={user.avatar || 'https://via.placeholder.com/150'}
                                alt={user.name}
                                className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg"
                            />
                            {isEditing && (
                                <button className="absolute bottom-0 right-0 bg-indigo-600 text-white p-2 rounded-full shadow-lg">
                                    <i className="fas fa-camera"></i>
                                </button>
                            )}
                        </div>
                    </div>

                    {isEditing ? (
                        <form onSubmit={handleSubmit}>
                            <Card>
                                <div className="space-y-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Name
                                        </label>
                                        <input
                                            type="text"
                                            value={formData.name}
                                            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                                            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Bio
                                        </label>
                                        <textarea
                                            value={formData.bio}
                                            onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                                            rows="4"
                                            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Location
                                        </label>
                                        <input
                                            type="text"
                                            value={formData.location}
                                            onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                                            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Website
                                        </label>
                                        <input
                                            type="url"
                                            value={formData.website}
                                            onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                                            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        />
                                    </div>

                                    <div>
                                        <h3 className="text-lg font-medium text-gray-900 mb-4">Social Media</h3>
                                        <div className="space-y-4">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    Instagram
                                                </label>
                                                <input
                                                    type="text"
                                                    value={formData.instagram}
                                                    onChange={(e) => setFormData(prev => ({ ...prev, instagram: e.target.value }))}
                                                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    YouTube
                                                </label>
                                                <input
                                                    type="text"
                                                    value={formData.youtube}
                                                    onChange={(e) => setFormData(prev => ({ ...prev, youtube: e.target.value }))}
                                                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    TikTok
                                                </label>
                                                <input
                                                    type="text"
                                                    value={formData.tiktok}
                                                    onChange={(e) => setFormData(prev => ({ ...prev, tiktok: e.target.value }))}
                                                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex justify-end space-x-4">
                                        <Button
                                            variant="ghost"
                                            onClick={() => setIsEditing(false)}
                                            disabled={loading}
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            type="submit"
                                            disabled={loading}
                                        >
                                            {loading ? (
                                                <i className="fas fa-spinner fa-spin mr-2"></i>
                                            ) : null}
                                            Save Changes
                                        </Button>
                                    </div>
                                </div>
                            </Card>
                        </form>
                    ) : (
                        <Card>
                            <div className="flex justify-end mb-6">
                                <Button onClick={() => setIsEditing(true)}>
                                    <i className="fas fa-edit mr-2"></i>
                                    Edit Profile
                                </Button>
                            </div>

                            <div className="space-y-6">
                                <div>
                                    <h2 className="text-2xl font-bold mb-2">{user.name}</h2>
                                    <p className="text-gray-600">{user.bio}</p>
                                </div>

                                <div className="flex items-center text-gray-600">
                                    <i className="fas fa-map-marker-alt mr-2"></i>
                                    {user.location}
                                </div>

                                {user.website && (
                                    <div className="flex items-center text-gray-600">
                                        <i className="fas fa-globe mr-2"></i>
                                        <a href={user.website} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-700">
                                            {user.website}
                                        </a>
                                    </div>
                                )}

                                <div className="border-t pt-6">
                                    <h3 className="text-lg font-medium text-gray-900 mb-4">Social Media</h3>
                                    <div className="flex space-x-4">
                                        {user.instagram && (
                                            <a href={user.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-pink-600">
                                                <i className="fab fa-instagram text-2xl"></i>
                                            </a>
                                        )}
                                        {user.youtube && (
                                            <a href={user.youtube} target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-red-600">
                                                <i className="fab fa-youtube text-2xl"></i>
                                            </a>
                                        )}
                                        {user.tiktok && (
                                            <a href={user.tiktok} target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-black">
                                                <i className="fab fa-tiktok text-2xl"></i>
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </Card>
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('Profile page error:', error);
        reportError(error);
        return null;
    }
}
