function Community() {
    try {
        const [posts, setPosts] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [showNewPostModal, setShowNewPostModal] = React.useState(false);
        const [newPost, setNewPost] = React.useState({ title: '', content: '' });
        const [selectedCategory, setSelectedCategory] = React.useState('all');

        React.useEffect(() => {
            loadPosts();
        }, [selectedCategory]);

        const loadPosts = async () => {
            try {
                const data = await api.getPosts();
                setPosts(data);
            } catch (error) {
                console.error('Failed to load posts:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleCreatePost = async (e) => {
            e.preventDefault();
            try {
                const post = await api.createPost(newPost);
                setPosts(prev => [post, ...prev]);
                setShowNewPostModal(false);
                setNewPost({ title: '', content: '' });
            } catch (error) {
                console.error('Failed to create post:', error);
            }
        };

        const handleLikePost = async (postId) => {
            try {
                await api.likePost(postId);
                setPosts(prev => prev.map(post => {
                    if (post.id === postId) {
                        return { ...post, likes: post.likes + 1, isLiked: true };
                    }
                    return post;
                }));
            } catch (error) {
                console.error('Failed to like post:', error);
            }
        };

        const categories = [
            { id: 'all', name: 'All Posts' },
            { id: 'tips', name: 'Tips & Tricks' },
            { id: 'questions', name: 'Questions' },
            { id: 'success', name: 'Success Stories' },
            { id: 'collaboration', name: 'Collaborations' }
        ];

        const filteredPosts = selectedCategory === 'all' 
            ? posts 
            : posts.filter(post => post.category === selectedCategory);

        return (
            <div data-name="community-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold">Community</h1>
                    <Button
                        onClick={() => setShowNewPostModal(true)}
                        className="flex items-center"
                    >
                        <i className="fas fa-plus mr-2"></i>
                        Create Post
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    <div className="lg:col-span-1">
                        <Card className="sticky top-4">
                            <h3 className="text-lg font-semibold mb-4">Categories</h3>
                            <div className="space-y-2">
                                {categories.map(category => (
                                    <button
                                        key={category.id}
                                        onClick={() => setSelectedCategory(category.id)}
                                        className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                                            selectedCategory === category.id
                                                ? 'bg-indigo-50 text-indigo-600'
                                                : 'text-gray-600 hover:bg-gray-50'
                                        }`}
                                    >
                                        {category.name}
                                    </button>
                                ))}
                            </div>

                            <div className="mt-8">
                                <h3 className="text-lg font-semibold mb-4">Community Guidelines</h3>
                                <ul className="space-y-3 text-sm text-gray-600">
                                    <li className="flex items-start">
                                        <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                                        Be respectful and supportive
                                    </li>
                                    <li className="flex items-start">
                                        <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                                        Share valuable insights
                                    </li>
                                    <li className="flex items-start">
                                        <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                                        No spam or self-promotion
                                    </li>
                                    <li className="flex items-start">
                                        <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                                        Keep discussions professional
                                    </li>
                                </ul>
                            </div>
                        </Card>
                    </div>

                    <div className="lg:col-span-3">
                        {loading ? (
                            <div className="text-center py-12">
                                <i className="fas fa-spinner fa-spin text-3xl text-indigo-600"></i>
                            </div>
                        ) : (
                            <div className="space-y-6">
                                {filteredPosts.map(post => (
                                    <Card key={post.id}>
                                        <div className="flex items-start space-x-4">
                                            <img
                                                src={post.author.avatar}
                                                alt={post.author.name}
                                                className="w-10 h-10 rounded-full"
                                            />
                                            <div className="flex-grow">
                                                <div className="flex items-center justify-between mb-2">
                                                    <div>
                                                        <h3 className="font-semibold">{post.author.name}</h3>
                                                        <p className="text-sm text-gray-500">
                                                            {new Date(post.createdAt).toLocaleDateString()}
                                                        </p>
                                                    </div>
                                                    <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm">
                                                        {post.category}
                                                    </span>
                                                </div>
                                                <h4 className="text-xl font-semibold mb-2">{post.title}</h4>
                                                <p className="text-gray-600 mb-4">{post.content}</p>
                                                <div className="flex items-center space-x-4">
                                                    <button
                                                        onClick={() => handleLikePost(post.id)}
                                                        className={`flex items-center space-x-1 ${
                                                            post.isLiked ? 'text-indigo-600' : 'text-gray-500'
                                                        } hover:text-indigo-600 transition-colors`}
                                                    >
                                                        <i className={`${post.isLiked ? 'fas' : 'far'} fa-heart`}></i>
                                                        <span>{post.likes}</span>
                                                    </button>
                                                    <button className="flex items-center space-x-1 text-gray-500 hover:text-indigo-600 transition-colors">
                                                        <i className="far fa-comment"></i>
                                                        <span>{post.comments}</span>
                                                    </button>
                                                    <button className="flex items-center space-x-1 text-gray-500 hover:text-indigo-600 transition-colors">
                                                        <i className="far fa-share-square"></i>
                                                        <span>Share</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                <Modal
                    isOpen={showNewPostModal}
                    onClose={() => setShowNewPostModal(false)}
                    title="Create New Post"
                >
                    <form onSubmit={handleCreatePost}>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Title
                                </label>
                                <input
                                    type="text"
                                    value={newPost.title}
                                    onChange={(e) => setNewPost(prev => ({ ...prev, title: e.target.value }))}
                                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                    placeholder="What's on your mind?"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Content
                                </label>
                                <textarea
                                    value={newPost.content}
                                    onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                                    rows="4"
                                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                    placeholder="Share your thoughts..."
                                    required
                                />
                            </div>
                            <div className="flex justify-end space-x-4">
                                <Button
                                    variant="ghost"
                                    onClick={() => setShowNewPostModal(false)}
                                >
                                    Cancel
                                </Button>
                                <Button type="submit">
                                    Post
                                </Button>
                            </div>
                        </div>
                    </form>
                </Modal>
            </div>
        );
    } catch (error) {
        console.error('Community page error:', error);
        reportError(error);
        return null;
    }
}
