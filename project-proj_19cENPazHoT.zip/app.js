function App() {
    try {
        return (
            <div data-name="app" className="min-h-screen flex flex-col">
                <Navbar />
                <main className="flex-grow">
                    <Home />
                </main>
                <Footer />
            </div>
        );
    } catch (error) {
        console.error('App error:', error);
        reportError(error);
        return null;
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
