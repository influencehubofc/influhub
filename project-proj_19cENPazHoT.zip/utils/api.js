const API_BASE_URL = 'https://api.influencehub.com';

async function handleResponse(response) {
    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.message || 'An error occurred');
    }
    return data;
}

async function fetchWithAuth(endpoint, options = {}) {
    const token = localStorage.getItem('authToken');
    const headers = {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers
    };

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers
        });
        return await handleResponse(response);
    } catch (error) {
        console.error('API request failed:', error);
        throw error;
    }
}

const api = {
    // Auth endpoints
    login: (credentials) => fetchWithAuth('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
    }),
    
    register: (userData) => fetchWithAuth('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData)
    }),

    // Profile endpoints
    getProfile: () => fetchWithAuth('/profile'),
    updateProfile: (data) => fetchWithAuth('/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
    }),

    // Learning endpoints
    getCourses: () => fetchWithAuth('/courses'),
    getCourseDetails: (courseId) => fetchWithAuth(`/courses/${courseId}`),
    enrollCourse: (courseId) => fetchWithAuth(`/courses/${courseId}/enroll`, {
        method: 'POST'
    }),

    // Opportunities endpoints
    getOpportunities: (filters) => fetchWithAuth(`/opportunities?${new URLSearchParams(filters)}`),
    getOpportunityDetails: (id) => fetchWithAuth(`/opportunities/${id}`),
    applyForOpportunity: (id, application) => fetchWithAuth(`/opportunities/${id}/apply`, {
        method: 'POST',
        body: JSON.stringify(application)
    }),

    // Community endpoints
    getPosts: () => fetchWithAuth('/community/posts'),
    createPost: (post) => fetchWithAuth('/community/posts', {
        method: 'POST',
        body: JSON.stringify(post)
    }),
    likePost: (postId) => fetchWithAuth(`/community/posts/${postId}/like`, {
        method: 'POST'
    })
};
