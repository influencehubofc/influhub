function Card({ title, children, className = '', onClick, hoverable = true, ...props }) {
    try {
        const hoverClass = hoverable ? 'card-hover' : '';
        
        return (
            <div
                data-name="card"
                className={`bg-white rounded-xl shadow-sm p-6 ${hoverClass} ${className}`}
                onClick={onClick}
                {...props}
            >
                {title && <h3 className="text-xl font-semibold mb-4">{title}</h3>}
                {children}
            </div>
        );
    } catch (error) {
        console.error('Card component error:', error);
        reportError(error);
        return null;
    }
}
