function Button({ children, variant = 'primary', size = 'md', className = '', onClick, disabled = false, type = 'button', ...props }) {
    try {
        const baseStyles = "rounded-full font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2";
        
        const variants = {
            primary: "bg-[#FF46D1] text-white hover:bg-[#e03db9] focus:ring-[#FF46D1]",
            secondary: "bg-[#FF880C] text-white hover:bg-[#e67a0b] focus:ring-[#FF880C]",
            outline: "border-2 border-[#FF46D1] text-[#FF46D1] hover:bg-[#FF46D1] hover:text-white focus:ring-[#FF46D1]",
            ghost: "text-gray-600 hover:text-[#FF46D1] hover:bg-[#FF46D1]/10 focus:ring-gray-500"
        };
        
        const sizes = {
            sm: "px-4 py-1.5 text-sm",
            md: "px-6 py-2",
            lg: "px-8 py-3 text-lg"
        };
        
        const disabledStyles = disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer";
        
        return (
            <button
                data-name="button"
                type={type}
                className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${disabledStyles} ${className}`}
                onClick={onClick}
                disabled={disabled}
                {...props}
            >
                {children}
            </button>
        );
    } catch (error) {
        console.error('Button component error:', error);
        reportError(error);
        return null;
    }
}
