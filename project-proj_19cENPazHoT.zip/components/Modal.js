function Modal({ isOpen, onClose, title, children, size = 'md' }) {
    try {
        if (!isOpen) return null;

        const sizes = {
            sm: 'max-w-md',
            md: 'max-w-lg',
            lg: 'max-w-2xl',
            xl: 'max-w-4xl'
        };

        return (
            <div data-name="modal" className="fixed inset-0 z-50 overflow-y-auto">
                <div className="modal-overlay fixed inset-0" onClick={onClose}></div>
                
                <div className="relative min-h-screen flex items-center justify-center p-4">
                    <div className={`modal-content relative bg-white rounded-xl ${sizes[size]} w-full mx-auto`}>
                        <div className="flex justify-between items-center p-6 border-b">
                            <h3 className="text-xl font-semibold">{title}</h3>
                            <button
                                onClick={onClose}
                                className="text-gray-400 hover:text-gray-500 transition-colors"
                            >
                                <i className="fas fa-times text-xl"></i>
                            </button>
                        </div>
                        
                        <div className="p-6">
                            {children}
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Modal component error:', error);
        reportError(error);
        return null;
    }
}
