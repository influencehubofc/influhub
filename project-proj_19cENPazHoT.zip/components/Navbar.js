function Navbar() {
    try {
        const [isMenuOpen, setIsMenuOpen] = React.useState(false);

        return (
            <nav data-name="navbar" className="bg-white shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16">
                        <div className="flex items-center">
                            <a href="/" className="flex items-center">
                                <i className="fas fa-hashtag text-[#FF46D1] text-2xl mr-2"></i>
                                <span className="font-bold text-xl gradient-text">InfluenceHub</span>
                            </a>
                        </div>

                        <div className="hidden md:flex items-center space-x-4">
                            <a href="/learn" className="nav-link">Learn</a>
                            <a href="/opportunities" className="nav-link">Opportunities</a>
                            <a href="/community" className="nav-link">Community</a>
                            <a href="/profile" className="nav-link">Profile</a>
                            <button className="ml-4 px-4 py-2 rounded-full bg-[#FF46D1] text-white hover:bg-[#e03db9] transition-colors">
                                Get Started
                            </button>
                        </div>

                        <div className="md:hidden flex items-center">
                            <button 
                                onClick={() => setIsMenuOpen(!isMenuOpen)}
                                className="text-gray-500 hover:text-[#FF46D1]"
                            >
                                <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
                            </button>
                        </div>
                    </div>
                </div>

                {isMenuOpen && (
                    <div className="md:hidden">
                        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                            <a href="/learn" className="block px-3 py-2 rounded-md text-gray-700 hover:text-[#FF46D1] hover:bg-[#FF46D1]/10">Learn</a>
                            <a href="/opportunities" className="block px-3 py-2 rounded-md text-gray-700 hover:text-[#FF46D1] hover:bg-[#FF46D1]/10">Opportunities</a>
                            <a href="/community" className="block px-3 py-2 rounded-md text-gray-700 hover:text-[#FF46D1] hover:bg-[#FF46D1]/10">Community</a>
                            <a href="/profile" className="block px-3 py-2 rounded-md text-gray-700 hover:text-[#FF46D1] hover:bg-[#FF46D1]/10">Profile</a>
                            <button className="w-full mt-4 px-4 py-2 rounded-full bg-[#FF46D1] text-white hover:bg-[#e03db9] transition-colors">
                                Get Started
                            </button>
                        </div>
                    </div>
                )}
            </nav>
        );
    } catch (error) {
        console.error('Navbar error:', error);
        reportError(error);
        return null;
    }
}
